Northwind Payments ? sprint review, rough notes
Attendees: Mira (facilitator), Priya, Sam. Rohan was absent and needs the decisions.

refund beta worked in staging. keep the first release behind the feature flag until support has the FAQ.
Decision: rollout stays behind the feature flag; we will review error rates before enabling it for everyone.
Priya will send the updated beta checklist by next Friday.
Sam will draft the support FAQ and ask Rohan to review it when he is back.
Risk: refund dashboard still misses declined-card reasons. Mira to check with analytics.
