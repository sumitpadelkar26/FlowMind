Billing service handover ? notes from Kabir to Rohan
Kabir away for two weeks. Rohan is interim owner.
Nightly invoices start at 02:00 UTC. Failed card payments retry three times over seven days.
Do not change retry timing without checking with the billing owner and finance.
If the Stripe webhook queue backs up, scale consumer to four replicas and replay dead-letter messages.
Tax-rates table update is due next week; confirm the reviewed values before deploying.
