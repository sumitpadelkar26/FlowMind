Incident review ? rough transcript
The payment webhook queue backed up after the deploy. Invoice updates were delayed, but no payment data was lost.
We rolled back the consumer change and replayed the dead-letter queue. Processing recovered in 18 minutes.
Decision: add a queue-depth alert and require a staged replay test before the next consumer release.
Anika will add the alert by next Wednesday. Dev will write the replay test and attach it to the release checklist.
